default[:rvm][:ruby][:implementation] = 'ruby'
default[:rvm][:ruby][:version] = '1.9.2'
