default[:rvm][:ruby][:implementation] = 'ruby'
default[:rvm][:ruby][:version] = '1.8.7'
