#!/bin/sh
exec /usr/local/rvm/scripts/rvm gem $*
