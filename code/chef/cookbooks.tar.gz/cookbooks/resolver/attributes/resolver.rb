set_unless[:resolver][:search] = domain
set_unless[:resolver][:nameservers] = [ "" ]
