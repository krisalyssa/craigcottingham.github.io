maintainer        "37signals"
maintainer_email  "sysadmins@37signals.com"
description       "Configures users and groups"
version           "0.1"
