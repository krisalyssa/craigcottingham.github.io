set_unless[:kickstart][:rootpw] = nil
set_unless[:kickstart][:virtual_host_name] = "build.#{domain}"
