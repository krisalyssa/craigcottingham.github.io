maintainer        "37signals"
maintainer_email  "sysadmins@37signals.com"
description       "Configures SSL certificate"
version           "0.1"
