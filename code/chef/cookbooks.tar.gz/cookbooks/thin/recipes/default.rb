gem_package "thin" do
  version node[:thin][:version]
end