default.thin[:version] = "1.2.5"
default.thin[:persistent_connections] = true