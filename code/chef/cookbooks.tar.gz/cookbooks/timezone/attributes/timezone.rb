timezone Mash.new unless attribute?("timezone")
timezone "UTC"