set_unless[:erlang][:gui_tools] = false
