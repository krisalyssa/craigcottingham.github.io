maintainer        "37signals"
maintainer_email  "sysadmins@37signals.com"
description       "Configures ddclient"
version           "0.1"
