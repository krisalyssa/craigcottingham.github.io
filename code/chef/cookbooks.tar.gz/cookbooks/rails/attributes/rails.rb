set_unless[:rails][:version]       = false
set_unless[:rails][:environment]   = "production"
set_unless[:rails][:max_pool_size] = 4
