package "maatkit"

remote_file "/usr/bin/mk-query-digest" do
  source "mk-query-digest"
  mode 0755
end