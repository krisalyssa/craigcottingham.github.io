rsnapshot Mash.new unless attribute?(:rsnapshot)
