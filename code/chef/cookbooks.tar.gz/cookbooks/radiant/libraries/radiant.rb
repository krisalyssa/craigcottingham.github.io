class Chef
  class Recipe
    def radiant_edge?
      @node[:radiant][:edge]
    end
  end
end