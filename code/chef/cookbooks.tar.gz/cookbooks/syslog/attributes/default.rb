syslog_ng Mash.new unless attribute?("syslog_ng")
syslog_ng[:root] = "/u/logs"