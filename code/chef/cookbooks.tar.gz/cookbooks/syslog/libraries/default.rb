def root
  @node[:syslog_ng][:root]
end