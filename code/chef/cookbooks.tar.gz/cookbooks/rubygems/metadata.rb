maintainer        "Opscode, Inc."
maintainer_email  "cookbooks@opscode.com"
license           "Apache 2.0"
description       "Opscode rubygems config"
long_description  <<-EOH
Configures rubygems sources lists
EOH
version           "0.1"
recipe            "rubygems", "Configures rubygems"
