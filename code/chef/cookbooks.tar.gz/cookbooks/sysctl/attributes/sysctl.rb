sysctl Mash.new unless attribute?(:sysctl)
